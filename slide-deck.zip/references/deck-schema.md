# deck.json スキーマリファレンス（v2: パラメーター駆動）

デッキは `<deck_dir>/deck.json` の 1 ファイルで管理する。**内容（コンテンツ）とデザイン（パラメーター）を分離**しており、デザインの微修正は JSON の数値を変えるだけで行える。AI に再生成させる必要はない。

```json
{
  "meta": { ... },
  "slides": [ { "type": "...", ..., "style": { ... } }, ... ]
}
```

## 座標系

- 仮想キャンバスは **1280 × 720 px（16:9）**。すべての位置・サイズ・フォントを px で指定する
- HTML は px をそのまま使い、PPTX は 96dpi で換算（px ÷ 96 = インチ、px × 0.75 = pt）する。座標・配色・フォントサイズの指定は共通ソース（テーマ＋レイアウト＋ deck.json）から解決されるため、HTML と PPTX の大枠のレイアウトは一致する（フォントの実体・画像の等比フィット・一部の図形表現などレンダラ由来の細部差は残る）
- **左右マージンは 72px、コンテンツ幅は 1136px** に統一されている（`title` / `section` / `bullets` / `table` など全タイプ共通のグリッド基準）。新しい領域を `style` で追加するときもこの基準に揃えると崩れにくい

## デザインの3層構造

| 層 | ファイル / キー | 役割 |
|----|----------------|------|
| テーマ | `templates/themes/<名前>.json` | 色トークンとフォント。`meta.theme` で選択 |
| レイアウト既定値 | `templates/layouts/default.json` | スライドタイプごとの全オブジェクト（領域）の位置・サイズ・フォント |
| オーバーライド | `meta.layout_overrides`（デッキ全体）/ `slides[i].style`（スライド個別） | 既定値への差分だけを書く |

解決順: **レイアウト既定値 ← meta.layout_overrides ← slides[i].style**（後勝ち・deep merge）。

全スライド共通の領域として `common.brand`（右上のブランド表記）があり、`meta.layout_overrides.common.brand` で全デッキ共通の位置・サイズを調整できる（3層構造の対象）。

### 微修正の例

```jsonc
// 5枚目のタイトルだけ 4px 下げて 40px にする
"slides": [ ..., { "type": "bullets", "title": "...",
  "style": { "title": { "y": 46, "size": 40 } } } ]

// このデッキ全体で箇条書きの本文を少し小さくする
"meta": { "layout_overrides": { "bullets": { "body": { "size": 22 } } } }
```

領域（`title`, `body`, `table` など）の名前と既定値は `templates/layouts/default.json` を見るのが早い。共通プロパティ: `x` `y` `w` `h`（px）、`size`（フォントpx）、`color` / `fill`（テーマトークン名 or hex 直書き）、`bold`、`align`（left/center/right）、`line_height`、`gap`（箇条書き間隔）など。

## meta

| キー | 必須 | 説明 |
|------|------|------|
| `id` | 省略可 | デッキ ID（出力ファイル名になる）。省略時はフォルダ名を使う。指定する場合は `\ / : * ? " < > \|` と制御文字を含められない（ファイル名として不正なため） |
| `title` | ✅ | デッキタイトル（フッターにも表示） |
| `subtitle` / `author` / `date` | | 補足情報 |
| `theme` | | テーマ名（省略時 `default`）。`templates/themes/` から選択（同梱: `default` / `accenture` / `acn-slide-master` / `acn-technology-graphik`。旧名 `accenture-purple` は `acn-slide-master` の別名） |
| `layout` | | レイアウト名（省略時 `default`） |
| `layout_overrides` | | デッキ全体のレイアウト調整（タイプ名 → 領域 → プロパティ）。`common.brand` も指定可 |
| `brand` | | 全スライド右上に表示する短いブランド表記（例: `ACME`）。アクセント色・太字・右寄せ。位置は `layout_overrides.common.brand` で調整 |
| `as_of` | | 資料の基準日（`"YYYY-MM"` か `"YYYY-MM-DD"`）。`lint_deck_text.py` の日付チェック（基準日より後の「実績」・基準日より前に始まる計画）に使う。省略時は `date`、それも無ければ今日の日付 |
| `line_balance` | | `false` で泣き別れ対策（最終行が1〜2文字になる文への自動改行）をデッキ全体で止める。既定は有効 |

## slides — スライドタイプ一覧

全タイプ共通のオプション: `notes`（スピーカーノート。**HTML でのみ表示**、N キーで開閉。PPTX には出力されない）、`style`（レイアウトオーバーライド）、`relation`、`line_balance`。提案書向けタイプでは結論の帯 `conclusion` と出典の行 `source` も使える（下記「提案書向けタイプ共通」）。

- `relation`（任意）: そのスライドで見せる内容の関係。描画には使わず、`lint_deck_text.py` がタイプとの不一致を警告する。値と合うタイプ: `parallel`（並列）→ cards / bullets / two_column / table / matrix / image_text / status_table / summary / row_matrix / house、`sequence`（順序）→ steps / swimlane / schedule / sequence / dataflow / agenda / row_matrix、`flow`（流れ）→ dataflow / swimlane / steps / sequence / architecture、`hierarchy`（階層）→ architecture / bullets / table / org / house / kpi_tree、`cause`（因果）→ steps / dataflow / two_column / bullets / reasons、`contrast`（対比）→ two_column / table / matrix / status_table / reasons / row_matrix、`cycle`（循環）→ lifecycle / cycle
- `line_balance`（任意）: `false` でそのスライドの泣き別れ対策を止める。既定では `title` / `subtitle` / `lead` / `punch` / `message` と箇条書き（bullets / closing / image_text / two_column）の最終行が1〜2文字になるとき、ビルド時に文節の切れ目（助詞・読点の後など）で改行を入れる。改行（`\n`）を書いてある文字列は触らない

`eyebrow`（タイトル上の小さなサブタイトル。15px・アクセント色・太字。章や系列の目印に使う）は、見出し（`chrome()`）を持つほぼ全タイプで指定できる: `bullets` / `two_column` / `table` / `code` / `image` / `image_text` に加え `agenda` / `steps` / `matrix` / `cards` / `swimlane` / `architecture` / `dataflow` / `lifecycle` / `sequence` でも使える（`title` / `section` / `quote` / `closing` のような固有レイアウトのタイプは対象外）。

ページ番号を消したい/変えたいスライドは `style.footer_r.text` に表示文字列を指定する（空文字は不可。既定はページ番号）。

### `title` — 表紙
```json
{ "type": "title", "title": "資料タイトル", "subtitle": "...", "meta": "社内勉強会 / 2026-08" }
```
領域: `bar`（左帯）, `title`, `subtitle`, `meta`

### `section` — 章扉
```json
{ "type": "section", "number": "01", "title": "...", "subtitle": "..." }
```
領域: `bg`, `number`, `title`, `rule`, `subtitle`

### `bullets` — 箇条書き
```json
{ "type": "bullets", "title": "見出し", "lead": "リード文（任意）",
  "bullets": [
    "文字列そのまま",
    { "text": "子項目つき", "children": ["子1", "子2"] },
    { "text": "強調したい行", "bold": true, "size": 26, "color": "accent" }
  ] }
```
領域: `title`, `rule`, `lead`, `body`, `footer_l`, `footer_r`。項目単位で `size` / `color` / `bold` を上書き可能（子項目も同様）。目安: **3〜6項目、1項目40字以内**（超えると自動的な折返し・縮小はされないため、`check_layout.py` の警告を確認する）。

既定は内容を上詰め（`valign: "top"`）。項目数が少ないスライドはキャンバス下半分が空白になりがちなので、`style.body.valign` を `"middle"` にすると `body` 枠（既定 y=192, h=456）の縦中央に項目群を寄せられる（`two_column` の `left`/`right` と同じ考え方。HTML/PPTX 共通で実際の描画高さに応じて自動的に中央寄せされるため、項目数を変えても再調整不要）。

### `two_column` — 2カラム比較
```json
{ "type": "two_column", "title": "見出し",
  "left":  { "heading": "左見出し", "bullets": ["..."] },
  "right": { "heading": "右見出し", "bullets": ["..."] } }
```
領域: `left` / `right`（ボックス）, `col_heading`, `col_body` ほか。既定は内容を上詰め（`valign: "top"`）。`style.left.valign` / `style.right.valign` を `"middle"` にすると箱内で縦中央寄せになる。

### `table` — 表
```json
{ "type": "table", "title": "見出し", "columns": ["列1", "列2"], "rows": [["a", "b"]],
  "style": { "table": { "row_h": 64, "cell_size": 16, "col_widths": [3, 3, 6], "border_color": "border" } } }
```
領域: `table`（`col_widths` は比率の配列。**要素数は `columns` と一致させること**（不一致はビルドエラー）。各行のセル数も `columns` の数と一致させる。`header_h` / `row_h` で行の高さ、`header_size` / `cell_size` でフォント、`border_color` で罫線色（テーマトークン、既定 `border`））。目安: **6行以内**（超える場合はスライドを分けるか要約する）。

セル全体が `http://` または `https://` のURLなら、HTMLではクリック可能なリンク、PPTXでは外部ハイパーリンクとして自動出力する。説明文にURLを混ぜたセルは自動リンク化しない。

URLを見せず、資料名など別の文字列をリンクにする場合は、セルを `{"text": "表示文字列", "url": "https://..."}` と書く。セル値が `null`（JSON の `null`）の場合は空文字として表示される。

**リンク先のスキーム制限（セキュリティ）**: リンクとして出力できるのは `http` / `https` / `mailto` のスキームだけ。ビルダーは href に出力する直前に `urlparse` でスキームを取り出して許可リストと突き合わせ、
- 自動リンク化（セル全体がURL）の対象は `http` / `https` のみ
- 明示指定の `url` は `http` / `https` / `mailto` のみ

とし、`javascript:` / `data:` / `vbscript:` / `file:` などが指定された場合は**ビルドエラー**にする（`url` を明示指定した場合）。文字列セルとして書かれた `javascript:...` はリンク化されず、そのまま通常のテキストとして表示される。HTMLのエスケープ（`<` `>` `&` `"` `'`）ではスキーム由来のXSSは防げないため、この許可リストで弾いている。

行単位の背景色は `style.table.row_fills` で指定する（キーは 0 始まりの行番号の文字列、値はテーマトークン or hex）。指定のない行は従来どおり交互色。意味のある行（例: AI 関連の行）に「しるし」を付ける用途に使う（強調色には `highlight_fill` トークンを推奨）:
```json
{ "type": "table", "...": "...",
  "style": { "table": { "row_fills": { "3": "highlight_fill" } } } }
```

### `status_table` — 進捗ステータス表（信号＋実績／計画）
```json
{ "type": "status_table", "title": "1. 全体・個別進捗報告（1/2）", "lead": "10/9(金)時点で、各チーム予定通り進行中。",
  "columns": ["チーム", "進捗状況", "実績（10/9時点）", "計画（今週末時点）"],
  "rows": [
    { "label": "PMO", "status": "green",
      "cells": [
        [ { "text": "進捗管理、課題管理等", "children": ["（継続）進捗管理", { "text": "論点議論", "children": ["顧客対応：…"] }] } ],
        [ "計画の項目" ]
      ] }
  ] }
```
- 1列目＝ラベル列（`label`、`highlight_fill` 地）、2列目＝信号（`status` の色の ●）、3列目以降＝内容列。`cells` の数は `columns` 数 − 2 と一致させる（不一致はビルドエラー）。
- セル内は文字列 or `{ "text", "children" }` の入れ子。最上位は ✓＋下線、2階層目以降は • で、階層ごとに字下げされる（PPTX ではネイティブ箇条書き）。
- `status` は凡例の `key`、テーマトークン、`#hex` のいずれか。凡例（右上）は `legend: [{ "key", "color", "label" }]` で指定し、省略時は赤（日程再調整が必要）／黄（リカバリ予定有）／緑（予定通り）の3色。`legend: false` で非表示、`legend_title` で凡例左の見出しを変更。
- 行の高さはセル内容から自動計算し、`table.fill_height`（既定 true）なら表の高さ（`table.h`）いっぱいまで比例配分する。内容が収まらない見込みならビルド時に warning。
- 領域: `title`（凡例と重ならないよう既定幅 690px）, `rule`, `lead`, `legend`, `table`（`col_widths` / `header_h` / `cell_size` / `label_size` / `status_size` / `indent` / `border_color` / `check_char` / `bullet_char` / `heading_underline` 等）, `footer_l/r`。
- 1枚3行程度が目安。PPTX は PowerPoint のネイティブ表として出力されるので、文字や信号の色を PowerPoint 上でも編集できる。

### 既存タイプの拡張（提案書の型に合わせたオプション）
- `agenda`: 項目に `desc`（説明文）を書くと、項目名の下に小さく説明が入る（行の高さは自動で 64px に広がる）。`{"text": "背景と目的", "desc": "…"}`
- `table`: `row_header: true` で1列目を行見出し（淡い色の塗り・太字）、`total_row: true` で最終行を合計行（`surface` 塗り・太字）にする。色は `style.table.label_fill` / `total_fill` / `label_color`
- `two_column`: `connector: "arrow"` で左右の箱の間に灰色の三角（左から右への流れ・因果）を置く（目的 → 骨子など）
- `steps`: `header_style: "arrow"` で見出しを工程の矢羽根（先頭は五方向、2つ目以降は山形）にし、間の「›」をなくす
- `matrix`: `points: [{"label": "本番ガード", "x": 0.8, "y": 0.9, "highlight": true, "n": 1}]` で格子の上に項目を番号付きの点で置く（`x` は右、`y` は上ほど大きい 0〜1）。散布して優先度を見せるときに使う
- `code`: `annotations: [{"line": 6, "title": "確認", "text": "…"}]` で右に番号付きの注釈を並べ、該当行に同じ番号の丸と左端の印を付ける（コードの幅は自動で6割に狭まり、文字は横幅にも収まるよう縮む）

### `code` — コード / 設定例
```json
{ "type": "code", "title": "見出し", "language": "yaml", "code": "type: Concept\n..." }
```
領域: `code`。行数が多いときは `min_size` まで自動縮小（HTML/PPTX 共通ロジック）。折り返しはせずクリップする（HTML/PPTX 共通）ので、1行が極端に長いコードは事前に改行を入れる。

### `quote` — 引用・キーメッセージ
```json
{ "type": "quote", "text": "強調したい一文", "attribution": "出典（任意）" }
```
領域: `mark`, `text`, `attribution`

### `image` — 画像
```json
{ "type": "image", "title": "見出し（任意）", "path": "assets/figure.png", "caption": "..." }
```
`path` はデッキフォルダ配下（`assets/` 推奨）の相対パスのみ（デッキフォルダの外を指すパスや存在しないファイルはビルドエラー）。対応拡張子: png / jpg / jpeg / gif / bmp / svg / webp / tiff。領域 `img`（既定 1136×440px、比率 約2.58:1）の枠内に等比で収まる（拡大・縮小どちらも行う）。**推奨アスペクト比は 4:3 〜 2:1**（例 1024×768、1200×600）。極端な縦長・横長の画像は左右または上下に余白（レターボックス/ピラーボックス）ができる。

**画像アセットはテーマに自動追従しない。** SVG/PNG 等の画像は静的なファイルなので、`meta.theme` を切り替えても配色・背景は変わらない。暗色系テーマ（背景が濃色のテーマ）で白背景の図版を使うと、スライドの中で図版だけ浮いて見える。暗色テーマを使うデッキでは (a) 画像側もそのテーマの背景色に合わせて用意する、(b) 可能なら `swimlane` / `matrix` / `steps` などテーマトークンで自動的に配色されるネイティブ図解タイプを使う、のいずれかを検討する。

### `image_text` — 画像＋パンチライン＋本文（1枚で伝える統合レイアウト）
```json
{ "type": "image_text", "title": "見出し",
  "punch": "一目で伝えたい一文（全幅・太字・アクセント色）",
  "bullets": ["本文（bullets と同じ書式。children 可）"],
  "path": "assets/figure.png", "caption": "画像の下の補足（任意）",
  "image_side": "right" }
```
領域: `title`, `rule`, `punch`（全幅パンチライン）, `body`（本文カラム）, `img`（既定 524×378px）, `caption`, `footer_l/r`。
`image_side` を `"left"` にすると画像と本文の左右が入れ替わる（既定は右）。
**画像だけ・文章だけのページに分離せず、メッセージと図解を1枚に載せたいときはこのタイプを使う。**
画像は 4:3 前後（例: 1024×768）が最も収まりが良い。`path` の制約は `image` タイプと同じ（デッキフォルダ配下・対応拡張子のみ）。

### `closing` — まとめ
```json
{ "type": "closing", "title": "まとめ", "bullets": ["..."], "message": "締めの一言（任意）" }
```
領域: `bg`, `title`, `rule`, `body`, `message`。`message` の縦位置は既定で **`body` の実描画高さの直後**に自動配置される（`follow_body: true`。`body` が短ければ `message` が上に詰まり、長ければ下がる。下限 `min_y`、上限はレイアウトの既定 `y`）。`style.message.y` を明示すればその固定値が優先される。

### `agenda` — アジェンダ / 目次
```json
{ "type": "agenda", "title": "Agenda", "lead": "（任意）",
  "items": [ "はじめに", { "text": "本日の議題", "active": true }, "まとめ" ] }
```
領域: `title`, `rule`, `lead`, `body`, `footer_l/r`。各項目に自動で連番（`01`, `02`…）が付く。`active: true` の項目は面（`active_fill`）で強調され、文字色が `active_color` になる。`bullets` の代替ではなく「番号付き＋現在地ハイライト」が要るときに使う。

**自動2段組・ページ送り**（項目数に応じて自動。**deck.json に書いたスライド数より実際の出力枚数が増えることがある**）:
- 1列あたりの最大行数 `R = floor(body.h / (row_h+gap))`（既定値で **R = 8 行**）。
- 項目数 **N ≤ R** → 1段。**R < N ≤ R×max_cols** → 自動で2段（左列を上から埋めて右列へ）。**N > R×max_cols** → 次ページの agenda に自動で繰り越し（連番は通し、2枚目以降のタイトルに「（続き）」）。
- `body` の `max_cols`（既定 2）/ `row_h` / `gap` / `col_gap` で段数・行ピッチを調整できる。既定では **9〜16 項目=2段、17 項目以上=2ページ目**。

### `steps` — ステップチャート / フロー
```json
{ "type": "steps", "title": "見出し", "lead": "（任意）",
  "steps": [
    { "label": "研究開発", "items": ["基礎研究", "実験・検証"] },
    { "label": "社会実装", "items": ["インフラ整備"] }
  ] }
```
領域: `title`, `rule`, `lead`, `body`, `footer_l/r`。手順・フロー・バリューチェーンを横並びのカードで表現し、カード間をシェブロン（›）で接続する。ステップ数（3〜5推奨）に応じてカード幅は自動調整。各カードはヘッダ（`header_fill`＝primary、`STEP n` は `num_color`）＋本文の箇条書き（`items`）。色はテーマの `primary` / `surface` / `on_primary_soft` に固定されており、カードごとに任意の色を指定するオプションは無い（要素ごとに色を変えたい場合は `image` / `image_text` で図を用意する）。

**カードの高さ**: 既定（`style.body.fit: "content"`）では最も長いカードの内容に合わせて高さを縮め、行全体を領域の上寄り中央に置く（短い内容で下半分が空くのを防ぐ）。下限は `style.body.min_h`（既定 260px）、上限は `body.h`。従来どおり領域いっぱいに描きたいときは `"fit": "fill"`。カードの枠線色は `card_border`（既定 `border` トークン）。

### `matrix` — 2×2 マトリクス
```json
{ "type": "matrix", "title": "見出し", "lead": "（任意）",
  "x_axis": { "label": "モデルの複雑さ", "low": "低", "high": "高" },
  "y_axis": { "label": "データの量", "low": "少", "high": "多" },
  "quadrants": [
    { "heading": "…", "body": "…", "highlight": true },
    { "heading": "…", "body": "…" },
    { "heading": "…", "body": "…" },
    { "heading": "…", "body": "…" }
  ] }
```
領域: `title`, `rule`, `lead`, `grid`, `axis`, `footer_l/r`。`quadrants` は**必ず4個**（左上 → 右上 → 左下 → 右下の順）。4個未満は残りが空象限になり、5個以上は5個目以降が無視され警告が出る。y軸は上が `high`、x軸は右が `high`。`highlight: true` の象限は `highlight_fill`／`hi_heading_color`（accent）で強調する。単純な行列は `table`、2軸の位置づけは `matrix` を使い分ける。既定で箱内のコンテンツは縦中央寄せ（`grid.valign: "middle"`）。`style.grid.valign: "top"` にすると上詰めに戻せる。

### `cards` — ボックスチャート / カードグリッド
```json
{ "type": "cards", "title": "見出し", "lead": "（任意）", "columns": 3,
  "cards": [
    { "heading": "Python", "body": "汎用・データ分析", "items": ["初学者向け", "AI/ML の定番"] },
    { "heading": "Go", "body": "クラウド基盤" }
  ] }
```
領域: `title`, `rule`, `lead`, `grid`, `footer_l/r`。整理軸に沿って要素カードを並べる（`two_column` の一般化）。`columns` で列数を指定（既定 3、数値で渡す）、カード数に応じて行が自動で折り返す。各カードは `heading`＋任意の `body`＋任意の `items`（箇条書き）。目安: **カード3〜6枚**。既定で箱内のコンテンツは縦中央寄せ（`grid.valign: "middle"`）。`style.grid.valign: "top"` にすると上詰めに戻せる。カードごとの色分け（系列色）は無く、全カード同一の配色（`surface` 地）になる。

### `swimlane` — スイムレーン業務フロー
```json
{ "type": "swimlane", "title": "見出し", "lead": "（任意）",
  "cols": 6,
  "phases": ["", "作成", "精緻化", "レビュー", "判定", "次工程"],
  "lanes": [
    { "group": "Japan", "name": "開発T(Lead)" },
    { "group": "Japan", "name": "開発T(Member)" },
    { "name": "AI（Claude Code等）" }
  ],
  "nodes": [
    { "id": "start", "lane": 0, "col": 0, "shape": "terminal", "text": "開始" },
    { "id": "t1", "lane": 1, "col": 1, "shape": "task", "text": "ドラフト作成", "loop": true },
    { "id": "d1", "lane": 1, "col": 2, "shape": "decision", "text": "指摘あり" },
    { "id": "io1", "lane": 2, "col": 1, "shape": "io", "input": ["論点一覧"], "output": ["検討資料"] },
    { "id": "end", "lane": 1, "col": 3, "shape": "terminal", "text": "完了" }
  ],
  "edges": [
    { "from": "start", "to": "t1" },
    { "from": "t1", "to": "d1" },
    { "from": "d1", "to": "end", "label": "Y" }
  ] }
```
領域: `title`, `rule`, `lead`, `flow`, `footer_l/r`。業務フロー・運用フローを **image に頼らずネイティブ描画**する（座標を自動計算するのでズレない）。ノード・レーン帯・矢印はテーマの `primary` / `surface` / `on_primary_soft` / `highlight_fill` / `border` に固定される（系列ごとの色分けはできない。多系列を色分けしたい場合は `image` で図を用意する）。

- **レーン（横帯）＝役割**。`lanes[]` は上から順の行（1個以上必須）。`group`（Lv1）が同じ連続レーンは左端に縦帯でまとめられる。`group` を省けば **Lv1 なしのフラットなレーン** になる（Lv1 のみ・Lv1+Lv2 どちらも可）。
- **配置はグリッド**。各ノードに `lane`（行 index）と `col`（工程＝列 index、0始まり）を指定。**`id` はノード間で重複不可**（重複するとビルドエラー）。列数は `cols`（省略時はノードの最大 col+1。ノードの `col` が `cols` 以上の場合は `cols` を自動拡張して警告）。`phases[]` を書くと上部に工程ヘッダ帯が出る（列と対応、空文字で省略）。
- **ノード形状 `shape`**: `task`（角丸四角・`loop:true` で反復記号／`variant` で `onpf`＝オンラインPF・`onother`＝PF以外・`offline`＝オフラインを色分け）/ `system`（システム・サービス）/ `decision`（ひし形・分岐）/ `terminal`（楕円・前/次ページ等のラベル付き連結）/ `marker`（小さな丸・`kind` で `start`/`end`/`mid`）/ `connector`（ペンタゴン・分岐の遷移先）/ `mail`（メール配信）/ `io`（`input`/`output` の成果物リスト）。
- **エッジ `edges[]`**: `{ from, to, label, style }`。`from`/`to` は存在する `id` を指定する（未知の `id` はビルドエラー）。ノード id 同士を結ぶと、レーンをまたぐ L 字・Z 字の直交矢印を**自動ルーティング**する。`label` は Y/N などの分岐ラベル、`style: "dashed"` で破線（システム操作）になる（既定は実線＝作業の流れ）。
- **凡例 `legend`**: **既定 `true`**。true のとき、そのスイムレーンの**直前に凡例専用ページ（`swimlane_legend`）を自動挿入**する（業務フロー標準記号の一覧：作業3種・システム・分岐・成果物・開始/終了/途中・前/次ページ・遷移先・メール・実線/破線の15種）。**この自動挿入は合計ページ数に影響する（+1枚）**。指定枚数を厳守したい場合はあらかじめ考慮するか、`"legend": false` で凡例ページを省略する。`legend_title` で凡例ページのタイトル、`legend_items` で凡例内容をカスタムできる。
  - `legend_items` の正しい形は **4要素配列の配列**: `[[shape, variant_or_kind, label, description], ...]`（例: `[["task", "onpf", "オンラインPF作業", "..."], ["decision", "", "分岐", "..."]]`）。辞書形式 `{"shape": "...", "variant": "...", "label": "...", "desc": "..."}`（または `kind`/`label`/`desc`）も受理されるが、**要素数の合わない配列やこれ以外の形は文字化けした凡例の原因になる**ので必ず4要素配列（または上記の辞書キー）で書く。
- 色・線幅・ノードサイズは `flow` の各トークンで調整可（`task_onpf_fill` / `task_offline_fill` / `system_fill` / `marker_start` / `connector_fill` / `decision_fill` / `edge_color` / `lane_border`（レーン区切り線の色、既定 `border` トークン）など）。
- **v0.3.0 の変更点**（`architecture` 等の追加にともなう配線エンジン共通化）: 配線が下記「図解タイプ共通」と同じ共通ルーター（`tools/diagram_engine.py`）に置き換わった。見た目はほぼ従来どおりだが、線が途中のノードを横切らなくなり、同じ辺から出る複数の線・同じ回廊を通る線は自動で等間隔にずれ、ラベルは背景ピル付きで重なりにくくなる。
  - `edges[].variant`（`default` / `emphasis` / `security` / `dashed`）と `edges[].arrow`（`end` / `both` / `none`）が使える。従来の `style: "dashed"` は引き続き受理する（両方書くと `style-conflict` の警告になり `variant` を優先する）。
  - ノードの `text` の別名として `label` も受理する。
  - `decision`（ひし形）は箱に内接するサイズで描かれるようになり、HTML と PPTX の大きさが一致する（従来は HTML だけ大きく見えていた）。
  - 反復記号 `loop: true` は右上の丸バッジ（円弧矢印）に変わった。
  - 追加された検証（warning）: ノードの `variant` が `onpf` / `onother` / `offline` 以外（`architecture` 系タイプの `emphasis` 等は swimlane では使えない）、`shape` が未知、`text`/`label` が無い、`edges[].variant` / `edges[].style` の未知値。
  - 凡例ページ（`legend` bool による自動挿入）と凡例記号15種、`groups` を持たない点は変わらない。

### 図解タイプ共通（`architecture` / `dataflow` / `lifecycle`）

この3タイプは同じ描画エンジン（`tools/diagram_engine.py`）を共有し、ノード・エッジの語彙とトークンも共通。タイプごとの違いは行・列の意味づけだけで、詳細は次項以降の各タイプ節を見る。ノード・エッジの見た目トークン（`node_*` / `edge_*` / `label_*` など）は `sequence` の参加者・メッセージにも使われる（自動配線・groups・凡例は grid 系3タイプ専用）。

領域名は共通で `diagram`（既定 `x=72 y=190 w=1136 h=468`。`style.diagram.*` または `meta.layout_overrides.<type>.diagram.*` で調整する）。図全体を `rows`×`cols` のセルに分け、ノードはセル中央に置かれる（`cols`/`rows` は省略可。ノードの最大 `col`/`row`+1、または見出し数から自動算出）。

**ノード `nodes[]`**（lifecycle は `states[]` も同じ形）

| フィールド | 必須 | 説明 |
|---|---|---|
| `id` | ✅ | 一意な id（英数字推奨）。重複は `duplicate-id` エラー |
| `label`（別名 `text`） | 推奨 | 表示名（無いと `missing-label` 警告） |
| `sublabel` | | 小さな補足（1行） |
| `tag` | | 右上の小ピル（例: `"JWT"`） |
| `type` | | `frontend` / `backend` / `database` / `cloud` / `security` / `messagebus` / `external` / `generic`（既定）。**色ではなくアイコンの形**でコンポーネントの役割を表す |
| `variant` | | `default`（既定）/ `emphasis` / `security` / `dashed` / `muted`。**色はこちらが担う** |
| `row` / `col` | | 0始まりの整数。同じ (row, col) の重複は `cell-collision` エラー、負値や非整数は `invalid-position` エラー |

**エッジ `edges[]`**

| フィールド | 必須 | 説明 |
|---|---|---|
| `from` / `to` | ✅ | 既知の `id`（未知は `unknown-endpoint` エラー） |
| `label` | | ラベル文字列 |
| `variant` | | `default` / `emphasis` / `security` / `dashed`。旧 swimlane 互換の `style: "dashed"` も受理（`variant` と両方書くと `style-conflict` 警告、`variant` を優先） |
| `arrow` | | `end`（既定）/ `both` / `none` |
| `from_side` / `to_side` | | `left` / `right` / `top` / `bottom`。他ノードを避けられない場合は無視され `side-ignored` 警告 |
| `via` | | `[[x, y], ...]`（キャンバス絶対 px の経由点）。**最初から書かず、`check_diagram.py` が提示してから 1 つ加える** |
| `label_at` | | `[x, y]`（ラベル中心の固定座標） |
| `route` | | `auto`（既定）/ `straight` |
| `classification` | | `dataflow` 用。ラベルの2行目に小さく表示（例: 「個人データ」） |

**別名**: 列見出し帯は `col_headers`（正式）＝ `stages`（dataflow で自然）＝ `phases`（swimlane 流）のどれでも同じ。行見出しは `lanes: [{"name": "..."}]`（正式。`label` も可）＝ `row_headers`。lifecycle は `states`=`nodes`、`transitions`=`edges`、ノードの `lane`=`row`。dataflow はノードの `stage`=`col`、`flows`=`edges`。

**グループ（境界） `groups[]`**: `{ "label", "kind": "region" | "security" | "zone" | "generic", "nodes": [id, ...] }`。メンバーの外接セル範囲を囲む（`region`=破線、`security`=primary破線、`zone`=surface塗り）。範囲内に非メンバーが混ざると `group-leak` 警告（**本当の所有・信頼・配備の境界だけ**に使い、単なる見た目のグルーピングには使わない）。swimlane の `lanes[].group`（縦帯グループ）とは別概念で、swimlane には `groups` は無い。

**凡例 `legend`**: `"auto"`（既定。`type` が2種以上あると図の下に1行で表示）/ `true` / `false`。**ページを追加しない**（swimlane の `legend` bool＝凡例ページの自動挿入とは意味が違う）。type の表示名既定は「フロント／バックエンド／DB／クラウド／セキュリティ／メッセージ基盤／外部」（`style.diagram.type_labels` で変更可）。

**自動配線**: 列・行のガターとノード中心線を格子にした最短の直交経路を探索し、途中のノードを横切らないルートを優先する（横切ってしまう場合は `edge-through-node` の診断。ビルド自体は止まらず警告として報告される）。同じ辺から出入りする複数の線・同じ回廊を通る線は自動で等間隔にずらす。ラベルは最長セグメントの脇に背景ピル付きで置き、ノード・他ラベルと衝突すれば別候補へ、それでも衝突すれば `label-collision` 警告（`label_at` の候補座標が提示される）。`from == to` の自己ループは右上の小さなコの字で描く。

**主な `style.diagram` トークン**（既定値は `templates/layouts/default.json` 参照）: `node_wr` / `node_hr` / `node_max_w` / `node_max_h` / `node_radius` / `node_pad` / `node_size` / `sub_size` / `tag_size` / `node_fill` / `node_border` / `node_border_w` / `node_color` / `sub_color` / `emphasis_fill` / `emphasis_border` / `security_border` / `dashed_border` / `muted_color` / `tag_fill` / `tag_color` / `icon_size` / `icon_color` / `group_border` / `group_color` / `group_radius` / `security_group_border` / `zone_fill` / `header_h` / `header_fill` / `header_color` / `row_label_w` / `row_fill` / `row_color` / `edge_color` / `edge_w` / `edge_emphasis_color` / `edge_security_color` / `edge_dashed_color` / `edge_return_color` / `label_size` / `label_color` / `label_fill` / `legend_h` / `type_labels`。dataflow 追加: `class_size` / `class_color`。lifecycle 追加: `start_` / `active_` / `waiting_` / `decision_` / `success_` / `failure_` / `neutral_` / `external_` の `_fill` / `_border`、`success_color` / `step_color` / `step_size`。

### `architecture` — システム構成図
```json
{ "type": "architecture", "eyebrow": "SYSTEM", "title": "システム構成",
  "nodes": [
    {"id":"web","type":"frontend","label":"Web","sublabel":"React","row":0,"col":0},
    {"id":"api","type":"backend","label":"API","sublabel":"FastAPI","row":0,"col":1,"variant":"emphasis"},
    {"id":"db","type":"database","label":"PostgreSQL","row":0,"col":2},
    {"id":"auth","type":"security","label":"認証","sublabel":"OAuth","row":1,"col":1}
  ],
  "groups": [{"label":"VPC","kind":"region","nodes":["api","db","auth"]}],
  "edges": [
    {"from":"web","to":"api","label":"HTTPS","variant":"emphasis"},
    {"from":"api","to":"db","label":"SQL"},
    {"from":"auth","to":"api","label":"JWT検証","variant":"security"}
  ] }
```
領域・フィールド・別名・groups・凡例・配線・`style.diagram` トークンは上記「図解タイプ共通」を参照。

目安: ノード12個以下、列6以下（超えると `too-dense` 警告で自動拡張はしない）。

注意: コンポーネントの役割は `type`（アイコンの形）で表し、強調したいノード／境界越えの通信は `variant`（ノードは `emphasis`、エッジは `security` 等）で表す。主経路が1本の左→右（または上→下）になるよう `row`/`col` を揃えると線が交差しにくい。

**AWS 風タイルアイコン**: `style.diagram.icon_style` を `"aws"` にすると、`type` を **カテゴリ色の角丸タイル＋白いグリフ**（AWS の構成図アイコン風）で描く（既定は `"line"` の線画グリフ）。実物の AWS アイコン画像は使わず自作しているので、テーマ・PPTX・HTML すべてで同じに出る。タイル色は `icon_tile_<type>` トークンで上書きでき（既定: frontend=マゼンタ / backend=オレンジ / database=ブルー / cloud=ティール / security=レッド / messagebus=ピンク / external=スレート / generic=グレー）、タイルの大きさは `icon_tile_size`（既定 30）。`architecture` / `dataflow` / `sequence` で有効（`lifecycle` は kind の形で表すのでタイルにはしない）。`legend_page` の凡例はこの設定を自動で引き継ぐので、図と凡例で見た目が揃う。

### `dataflow` — データフロー
```json
{ "type": "dataflow", "eyebrow": "DATA", "title": "データフロー",
  "stages": ["収集", "処理", "保存", "活用"],
  "nodes": [
    {"id":"app","type":"frontend","label":"アプリ","col":0,"row":0},
    {"id":"collector","type":"cloud","label":"収集API","col":1,"row":0},
    {"id":"stream","type":"messagebus","label":"Kafka","col":2,"row":0},
    {"id":"dwh","type":"database","label":"DWH","col":3,"row":0}
  ],
  "edges": [
    {"from":"app","to":"collector","label":"送信"},
    {"from":"collector","to":"stream","label":"正規化"},
    {"from":"stream","to":"dwh","label":"格納","classification":"匿名化済み"}
  ] }
```
領域・フィールド・別名・凡例・配線・`style.diagram` トークンは上記「図解タイプ共通」を参照。`stages` は列見出し（`col_headers` の別名）で、工程を上部の帯に表示する。

目安: 列（`stages` の数、または最大 `col`+1）6以下、ノード12個以下。

注意: `edges[].classification` はラベル下に小さく表示され、データの区分（個人データ・匿名化済み等）を添えるのに使う。`row` は同じ工程内で並行する経路の書き分けに使う（lifecycle の `lane` と役割が近い）。

### `lifecycle` — ライフサイクル / 状態遷移
```json
{ "type": "lifecycle", "eyebrow": "STATE", "title": "承認フローの状態遷移",
  "lanes": [{"name":"主経路"},{"name":"差し戻し"}],
  "states": [
    {"id":"draft","kind":"start","label":"下書き","lane":0,"col":0},
    {"id":"review","kind":"decision","label":"レビュー","lane":0,"col":1},
    {"id":"done","kind":"success","label":"承認済み","lane":0,"col":2},
    {"id":"reject","kind":"failure","label":"差し戻し","lane":1,"col":1}
  ],
  "transitions": [
    {"from":"draft","to":"review"},
    {"from":"review","to":"done","label":"OK","variant":"emphasis"},
    {"from":"review","to":"reject","label":"NG"},
    {"from":"reject","to":"draft","label":"再提出","variant":"dashed"}
  ] }
```
`states`（`nodes` も受理）と `transitions`（`edges` も受理）を使う。`lane` は `row` の別名で、`lanes[]`（1個以上）が縦の帯になる（Archify のように main/terminal の3帯固定ではなく、任意の本数を書ける）。状態の性質は `kind` で描き分ける:

| `kind` | 見た目 |
|---|---|
| `start` | ピル形。accent 枠＋highlight_fill 塗り |
| `active`（既定） | 通常の角丸カード。primary 枠 |
| `waiting` | 破線・muted＋砂時計アイコン |
| `decision` | ひし形（accent 枠・highlight_fill 塗り） |
| `success` | accent 塗り・白文字＋チェック |
| `failure` | 太い破線＋×印 |
| `neutral` | surface 塗り |
| `external` | 破線・muted |

`step`（`"01"` のような番号バッジ）も指定できる。

目安: 状態12個以下。レーンは意味のある単位で3〜4本程度（本数の上限は無いが増やすほど1本あたりの文字が小さくなる）。

注意: 分岐は `decision`、成功/失敗の終端は `success`/`failure` を使い分けると状態の性質が一目で伝わる。

### `sequence` — シーケンス図
```json
{ "type": "sequence", "eyebrow": "FLOW", "title": "ログイン処理のやり取り",
  "participants": [
    {"id":"user","type":"external","label":"利用者"},
    {"id":"web","type":"frontend","label":"Web"},
    {"id":"api","type":"backend","label":"API"},
    {"id":"db","type":"database","label":"DB"}
  ],
  "messages": [
    {"from":"user","to":"web","label":"ログイン"},
    {"from":"web","to":"api","label":"POST /login","variant":"emphasis"},
    {"from":"api","to":"db","label":"SELECT user"},
    {"from":"db","to":"api","label":"rows","variant":"return"},
    {"from":"api","to":"web","label":"200 OK","variant":"return"}
  ] }
```
領域: `diagram`（他3タイプと共通）。上部に参加者カードを横並びに置き、下へライフライン（破線）を伸ばす。

| フィールド | 説明 |
|---|---|
| `participants[].id/label/sublabel/type/variant` | ノードと同じ語彙（`type` のアイコン、`variant` の `emphasis`/`security`/`dashed`/`muted` も使える） |
| `messages[].from/to/label` | 配列の**順に上から等間隔**に描く（`label` が無いと `missing-label` 警告） |
| `messages[].variant` | `default` / `emphasis` / `security` / `dashed` / `return`（戻りは破線の開いた矢印） |
| `activations[]`（任意） | `{ "participant", "from", "to" }`。`from`/`to` は `messages` の index（0始まり）または `id`。ライフライン上の帯 |
| `segments[]`（任意） | `{ "from", "to", "label" }`（同じく index/id）。区間を薄い破線枠で囲み左上にラベル |

`from == to` は自己メッセージ（右側に小さなコの字）として描く。

目安: 参加者7人以下、メッセージ12本以下（超えると `too-dense` 警告）。ラベルが矢印の長さより長いと `label-collision` 警告。

注意: 参加者カード・メッセージの矢印は「図解タイプ共通」節と同じノード/エッジのトークン・語彙で着色されるが、自動配線・groups・凡例（横切り回避を含む）は grid 系3タイプ専用でここには無い（メッセージは常に横一直線）。

### `schedule` — 矢羽根スケジュール（ガント／工程表）
```json
{ "type": "schedule", "eyebrow": "SCHEDULE", "title": "全体スケジュール",
  "timeline": { "start": "2026-09", "end": "2027-08", "unit": "month" },
  "periods": [ { "label": "FY27 Q1（2026/9〜11月）", "span": 3 }, { "label": "Q2", "span": 3 } ],
  "today": "2026-10-05",
  "rows": [
    { "group": "節目", "label": "マイルストーン",
      "milestones": [ { "at": "2026-10-31", "label": "10月末 RV完了" } ] },
    { "group": "開発", "label": "要件定義〜テスト", "sub": "開発チーム",
      "bars": [
        { "start": "2026-09", "end": "2026-10", "label": "要件定義" },
        { "start": "2026-11", "end": "2026-12-25", "label": "運用", "variant": "ongoing" } ] }
  ],
  "legend_labels": { "main": "主要タスク（成果物を出す）" },
  "note": "※ 注記（凡例の右端に表示）" }
```
領域: `title`, `rule`, `lead`, `chart`, `footer_l/r`。左に行見出し（`label`＋小さな `sub`）、上に時間軸（`periods` の大見出し＋列見出し）、右に矢羽根・節目・現在線を描く。**座標は書かない**。期間（日付・列）だけを書けば、エンジン（`tools/schedule_engine.py`）が時間軸に合わせて位置を計算するので、HTML と PPTX のどちらでも矢羽根の始点・終点が軸とズレない。PPTX では矢羽根＝ホームベース／山形、節目＝ひし形、見出し＝四角形のネイティブ図形で描き、文字も図形に直接入れるため、PowerPoint 上で1本ずつ選んで文言・色・長さを直せる（図全体は1つのグループ。ダブルクリックで中の図形を編集できる）。

- **時間軸**: `timeline`（`unit` は `month`＝"YYYY-MM"〜"YYYY-MM" / `week`＝"YYYY-MM-DD"〜"YYYY-MM-DD"、列見出しは自動で「9月」「10/5」形式）か、`columns`（列見出しの配列を直接指定）のどちらかが必須。両方書くと `columns` が見出しの表示文字列として使われる（数は timeline の列数と一致させる）。
- **位置の書き方**（`bars[].start` / `end`、`milestones[].at`、`today`）: `"YYYY-MM-DD"`（timeline 指定時。日単位で按分）/ `"YYYY-MM"`（start は月初、end は月末）/ 列見出しの文字列（例 `"10月"`。start は列の左端、end は列の右端）/ 数値（列単位。0 が先頭列の左端）。時間軸の範囲外・`end` が `start` 以前はビルドエラー。
- **行 `rows[]`**: `label`（必須推奨）/ `sub`（担当など小さく2段目）/ `group`（連続する同じ値を左端の縦帯にまとめる）/ `bars[]` / `milestones[]`。節目は専用の行（例「マイルストーン」）に置くのを推奨（近いラベルは自動で段をずらし、行の高さも自動で確保する）。
- **矢羽根 `bars[]`**: `{ start, end, label, variant, shape, label_pos }`。`variant`: `main`（既定・primary 塗り）/ `accent`（accent 塗り）/ `muted`（muted 塗り）/ `prep`（淡色＋枠）/ `ongoing`（白地＋枠）/ `tbd`（白地＋破線枠＝要調整・未確定）。`shape`: `arrow`（既定・ホームベース）/ `chevron`（山形）/ `bar`（四角）。ラベルが矢羽根に収まらないと文字を縮め、それでも入らなければ `bar-label-overflow` 警告（`"label_pos": "after"` で矢羽根の右に出せる）。同じ行で期間が重なると `bar-overlap` 警告。
- **節目 `milestones[]`**: `{ at, label }`。ひし形＋下にラベル。
- **`periods[]`**: `{ label, span }`（span＝列数）。四半期・年度などの大見出し。境界の縦罫線は太線になる。
- **`today`**: 現在線（縦の破線）。日付で書くと凡例に「現在（10/5）」と自動表示。
- **凡例**: 既定で図の下に1行（使われた variant ＋ 節目 ＋ 現在線だけ）。`legend: false` で非表示、`legend_labels`（キーは variant 名・`milestone`・`today`）で文言を変更。収まらなければ文字を縮めてから自動で折り返す（`legend-wrapped` note）。`note` は凡例行の右端に出る注記。
- **行の高さ**: 図の高さ（lead があれば `chart.y/h`、無ければ `chart.y_no_lead/h_no_lead` で上に詰める）から自動で等分し、`min_row_h`〜`max_row_h` に収める。行が多く `min_row_h` を下回ると `too-dense` 警告（目安 14 行以下）。行が低いと行見出しの文字も比例して縮む。
- **主な `style.chart` トークン**: `label_w`（行見出し欄の幅、既定 250）/ `group_w` / `period_h` / `col_h` / `min_row_h` / `max_row_h` / `bar_hr`（行高に対する矢羽根の高さ比）/ `bar_max_h` / `bar_head`（矢頭の深さ上限 px）/ `bar_gap` / `<variant>_fill` / `<variant>_border` / `<variant>_color` / `period_fill` / `col_fill` / `group_fill` / `row_alt_fill` / `grid_color` / `milestone_fill` / `today_color` / 各 `*_size`。

診断は `check_diagram.py` で確認できる（スキーマ的な誤りはビルドエラー、文字あふれ・重なりは警告）。

### 提案書向けタイプ共通（`summary` / `reasons` / `statement` / `row_matrix` / `org` / `house` / `cycle` / `kpi_tree`）

提案書・報告書の定型ページを、人が作った提案書と同じ型で描くタイプ。レイアウトは `tools/proposal_engine.py` が計算し、HTML と PPTX の両方でネイティブ図形（PowerPoint では四角・矢羽根・線を1つずつ編集できる）になる。文字の大きさはテーマのフォントの実測字幅で行数を見積もり、枠に収まる最大のサイズを自動で選ぶ。`statement` 以外はタイトル・罫線・リード・フッターを持ち、本文は `body` 領域（lead が無ければ `y_no_lead` まで上に詰める）に描く。色・寸法は `style.body.<トークン>` で上書きできる（トークン名は `templates/layouts/default.json` の各タイプの `body`）。

**共通パーツ**（`title` / `section` / `quote` / `closing` / `canvas` / `statement` 以外の全タイプで使える）:
- `conclusion`: 本文の下に結論の帯（`primary` 塗り・白抜き太字・中央揃え）を付ける。帯の分だけ本文の領域が上に詰まる（既存タイプでは本文の領域の高さを、`table` では行の高さを自動で詰める）。見た目は `style.conclusion`（`h` / `gap` / `size` / `fill` / `color`）
- `source`: 本文の下に出典の行（12px・`muted`）を付ける。試算値は「試算の前提: …」と書く。見た目は `style.source`

### `summary` — 要旨（番号の箱＋要点＋説明の行）
```json
{ "type": "summary", "title": "ご提案の背景と要旨", "lead": "（任意）",
  "items": [ { "lead": "背景｜…", "text": "説明" }, { "lead": "課題｜…", "text": "…" } ],
  "source": "（任意）出典", "conclusion": "（任意）結論の帯" }
```
提案書の冒頭で結論と骨子を示す。各行は左に番号の箱（`primary`）、右に要点（太字）と説明。行の高さはすべて同じ。目安: **3〜6行**（7行以上は警告）。`items` に文字列だけを並べると要点だけの行になる。

### `reasons` — 選ばれる理由（課題 × 強みの対応）
```json
{ "type": "reasons", "title": "アクセンチュアが選ばれる理由",
  "left_heading": "貴社の課題", "right_heading": "選ばれる理由",
  "issues":    [ { "title": "判断材料が少ない", "text": "新機能で事例がない" } ],
  "strengths": [ { "title": "一次情報を読み解き…", "text": "（任意）", "items": ["根拠1", "根拠2"], "label": "a" } ] }
```
左に相手の課題（番号付き）、右に自社の強み（`label` 省略時は a/b/c…）を同じ行に並べ、間を灰色の三角でつなぐ。`issues` と `strengths` は同じ順で対応させる。目安: **3行前後**（6行以上は警告）。

### `statement` — 言い切り（濃色の面に大きな一文）
```json
{ "type": "statement", "kicker": "本提案の結論", "message": "Modsは、統制を先に固めた組織だけが、安全に増やせる",
  "support": "（任意）補足の一文" }
```
物語の転換点に置く全面ページ（タイトル・罫線・フッターなし）。`message`（無ければ `title`）を大きく、`kicker` を上に小さく、`support` を下に置く。長い一文は自動で文字を縮める。デッキに2〜3枚までが目安。領域: `background`（`fill`）/ `kicker` / `message` / `support`。

### `row_matrix` — 行見出し × 列の整理表
```json
{ "type": "row_matrix", "title": "フェーズ別の実施事項", "header_style": "arrow",
  "corner": "（任意）左上の見出し", "columns": ["Phase 0", "Phase 1", "Phase 2"], "col_ratios": [1, 1, 1],
  "emph_col": 0,
  "rows": [ { "label": "統制", "cells": [ ["現状の棚卸し", "管理設定の設計"], "文字列も可", { "text": "本文", "items": ["箇条書き"] } ] } ] }
```
左の行見出しの帯と上の列見出しで、観点×対象（機会とリスク、工程×領域、前提・参考資料など）を整理する。セルは文字列・箇条書きの配列・`{text, items}` のいずれか。`header_style: "arrow"` で列見出しを工程の矢羽根（五方向）にする。`emph_col`（0 始まり）で主張する列を淡い色で塗る。`columns` を省略（または `[""]`）すると、行見出し＋1列の一覧（前提条件・参考資料など）になる。行の高さは中身に合わせて配分し、余りは均等に足す。目安: **6行以内**。

### `org` — 体制図（左右の組織ツリー＋提案範囲）
```json
{ "type": "org", "title": "推進体制", "legend": "(F) フルタイム　(P) パートタイム",
  "left":  { "title": "貴社", "nodes": [ { "id": "po", "title": "プロジェクトオーナー", "name": "開発本部長" },
                                        { "id": "pm", "parent": "po", "title": "貴社PM", "name": "開発基盤部" } ] },
  "right": { "title": "アクセンチュア", "scope": "ご支援範囲",
             "nodes": [ { "id": "apm", "title": "プロジェクトマネージャー", "name": "1名 (F)", "members": "（任意）" } ] },
  "links": [ { "from": "po", "to": "apm", "label": "ステアリング" } ] }
```
左右（片方だけでも可）に組織のツリーを描く。ノードは `id` と `parent`（同じ側の親の id）で親子を表し、見出し帯（左は `muted`、右は `primary`）＋本文（`name` / `members`）の箱になる。親子はカギ線で結ぶ。`scope` を書いた側は破線の枠で囲み、文字列なら札（既定「ご支援範囲」）を付ける。`links` は組織をまたぐ連携（点線＋ラベル）。id の重複・存在しない parent / links はビルドエラー。目安: 各側 **3階層・1段4ノード以内**。

### アイコン（`icon`）
提案書向けタイプと `cards` の項目には `icon` を書ける。値は同梱アイコンの名前（例 `"shield-check"`）か概念語（例 `"セキュリティ"` / `"q:統制 安全"`）で、概念語なら最も近いアイコンが選ばれる（似た概念は同じ絵を使い回す）。アイコンは Tabler Icons（MIT License、`templates/icons/LICENSE-tabler.txt`）から定番の約70点だけを同梱しており、HTML でも PPTX でも線だけのネイティブ図形になる（PowerPoint で色・太さを変えられる）。合うアイコンが無い指定はビルド時に警告する。
- 置ける場所: `summary` の `items[].icon`（帯の左）/ `reasons` の `strengths[].icon`（強みの記号の右）/ `house` の `pillars[].icon`（柱の見出しの左）/ `cycle` の `stages[].icon`（パネルの右上）/ `cards` の `cards[].icon`（カードの右上）
- 一覧と検索: `python tools/icon_engine.py --list`、`python tools/icon_engine.py "コスト削減"`、一覧画像は `--sheet icons.png`
- アイコンは脇役として小さく（22〜28px）置く。アイコンだけで中身を語らせない

### `house` — 全体像（屋根・柱・土台）
```json
{ "type": "house", "title": "ご提案の全体像",
  "roof": { "title": "目指す姿｜安全に増やせるmod基盤", "text": "（任意）補足" },
  "pillars": [ { "title": "① 統制", "items": ["入口を絞る", "成果物: 方針書"] }, { "title": "② 構築", "text": "本文でも可" } ],
  "foundations": [ { "title": "土台", "text": "管理設定の配布" }, "文字列も可" ] }
```
屋根（台形の帯に目指す姿）、柱（見出し帯＋箇条書きの列）、土台（全幅の帯。最後が一番下）で提案の全体像を示す。柱の文字は収まる大きさに自動で縮む。目安: **柱3〜4本**（6本以上は警告）。

### `cycle` — 循環（中央の円＋円弧の矢印＋段のパネル）
```json
{ "type": "cycle", "title": "定着の仕組み", "center": "毎月",
  "stages": [ { "title": "計測", "items": ["使用状況", "失敗"] }, { "title": "改善", "text": "本文でも可" }, { "title": "審査" }, { "title": "配布" } ] }
```
中央に円弧の矢印の輪（番号丸つき）、左右に段のパネルを置く。右列が前半（上から）、左列が後半（下から）で、時計回りに読める。`center` は輪の中央の文字（任意）。目安: **3〜6段**（2段以下はビルドエラー、7段以上は警告）。

### `kpi_tree` — KPI ツリー（目標 → 方向性 → KPI＋目標値＋測り方）
```json
{ "type": "kpi_tree", "title": "期待する効果とKPI", "root": "mod基盤の価値",
  "headers": ["目標", "施策の方向性", "KPIと目標値", "", "測り方・具体例"],
  "branches": [ { "title": "止める（統制）", "kpis": [ { "title": "未承認modの稼働を無くす", "value": "0台", "note": "月次で棚卸し" } ] } ] }
```
左の目標から施策の方向性へ、方向性から KPI の行へカギ線でつなぎ、各 KPI に目標値（大きな数字）と測り方を添える。`headers` は列の見出し（4つ目は目標値の列で通常は空）。`note` の代わりに `items`（箇条書き）も可。目安: **KPI 6行以内**。

### `diagram_legend` — 図解タイプの凡例ページ
```json
{ "type": "diagram_legend", "eyebrow": "SYSTEM — 凡例", "title": "システム構成図の記号",
  "lead": "アイコンは役割、色は強調、矢印の線種は接続の性質を表す。",
  "items": [
    [{"icon": "backend"},     "バックエンド", "API・アプリケーションサーバ"],
    [{"node": "emphasis"},    "主要ノード",   "強調色＝主経路の中心"],
    [{"kind": "decision"},    "分岐",         "条件による分岐（ひし形）"],
    [{"edge": "default"},     "実線矢印",     "同期の呼び出し・主なデータの流れ"],
    [{"edge": "dashed"},      "破線矢印",     "非同期・任意・補助的な経路"],
    [{"edge": "return"},      "戻り矢印",     "開いた破線矢印＝応答・戻り値"]
  ] }
```
`architecture` / `dataflow` / `lifecycle` / `sequence` の記号を、swimlane の凡例ページと同じ「記号＋名前＋説明」の2カラム表で見せる専用タイプ。**記号は実図と同じ描画関数（`_node_visual` / `_edge_visual`）で描く**ので凡例と本体の見た目が必ず一致する。

**自動挿入（推奨）**: 図解スライド（`architecture` / `dataflow` / `lifecycle` / `sequence`）に **`"legend_page": true`** を付けると、そのスライドの直前に `diagram_legend` ページが自動挿入される（swimlane の `legend` と同じ仕組み。ただし**既定はオフ**で、付けたスライドにだけ着く）。`items` は**そのスライドで実際に使われている** `type` / `variant` / `kind` / エッジの種類だけから自動生成されるので、図に出てこない記号は載らない。オプション: `legend_title`（凡例の見出し）/ `legend_eyebrow`（既定はスライドの `eyebrow` に「 — 凡例」を付けたもの）/ `legend_lead`（説明文）/ `legend_items`（自動生成を使わず内容を明示。形式は下記）。`icon_style:"aws"` などアイコン関連の `style.diagram` トークンは凡例に自動で引き継がれる。

`diagram_legend` を直接スライドとして書けば、任意の位置・内容の凡例ページも作れる。その場合は次の `items` を指定する。

`items` は `[サンプル, ラベル, 説明]` の配列。**サンプルはキー1つの辞書**で、種類は次の4つ:

| サンプル | 描くもの |
|---|---|
| `{"icon": "<type>"}` | ノードカード＋type アイコン（`frontend` / `backend` / `database` / `cloud` / `security` / `messagebus` / `external`） |
| `{"node": "<variant>"}` | variant の色見本ボックス（`emphasis` / `security` / `dashed` / `muted`） |
| `{"kind": "<kind>"}` | lifecycle の状態記号（`start` / `active` / `waiting` / `decision` / `success` / `failure` / `neutral` / `external`。形とグリフ付き） |
| `{"edge": "<variant>"}` | 矢印1本（`default`＝実線 / `emphasis`＝太線 / `security`＝鎖線 / `dashed`＝破線 / `return`＝開いた破線の戻り矢印） |

領域は `area`（2カラムのグリッド。`cols` / `col_gap` / `row_h` / `sym_w` / `label_size` / `desc_size`）と `diagram`（記号の色トークン。`architecture` と同じ語彙＋lifecycle の kind トークン）。色を変えるときは `meta.theme` の切替か `style.diagram.*` で行う。

### `canvas` — 座標指定の自由配置（既存 PPTX の取り込み専用）

テーマのタイトル・罫線・フッターを付けず、1280×720 の座標に図形・文字・表を直接置く。用途は、既存の PowerPoint 資料を**見た目を崩さず** HTML 化すること（矢羽根付きのガントチャートやスイムレーン図など、他のタイプに当てはまらない自由配置の図）に限る。**`tools/pptx_import.py` で生成するもので、新規スライドを canvas で手書きしない**（テーマ切替・共通パーツ・自動レイアウトが効かないため。新規の図解・スケジュールは `architecture` / `schedule` 等を使う）。元 PPTX のマスター上の図形は各スライドの `elements` に展開される。

```json
{ "type": "canvas", "title": "全体スケジュール", "background": "#FFFFFF", "notes": "（任意）",
  "elements": [
    { "x": 280, "y": 280, "w": 51, "h": 21, "geom": "homePlate", "adj": {"adj": 13400},
      "fill": "#FFFFFF", "line": {"color": "#7F7F7F", "width": 0.75},
      "text": {"insets": [0, 0, 0, 0], "anchor": "ctr",
               "paragraphs": [{"align": "ctr", "runs": [{"text": "CRP", "size": 9.33, "color": "#000000", "font": ["Meiryo UI"]}]}]} },
    { "x": 68, "y": 262, "w": 1153, "h": 0, "geom": "line", "line": {"color": "#919191", "width": 0.75, "dash": "dash"} },
    { "kind": "table", "x": 40, "y": 250, "w": 1180, "h": 400, "cols": [200, 160], "rows": [ {"h": 40, "cells": [ ... ]} ] },
    { "kind": "svg", "x": 446, "y": 362, "w": 40, "h": 38, "svg": "<svg ...>…</svg>", "alt": "繰り返し" },
    { "kind": "placeholder", "x": 128, "y": 0, "w": 528, "h": 321, "label": "画像（スクリーンショット）" }
  ] }
```

- 単位はすべて px（文字サイズも px。pt × 4/3）。要素は配列の順に重なる（後ろほど手前）
- `background` は `#RRGGBB`。色は `"#RRGGBB"` か `{"color": "#RRGGBB", "alpha": 0.5}`（テーマトークンは使わない＝元資料の色をそのまま持つ）。色・`anchor` / `align` / `dash` / `cap` / 矢じりの値・フォント名・パス命令はビルド時に検証され、規定外の値はエラーになる
- PPTX に出力すると図形・線・表は PowerPoint ネイティブの図形になり、1つずつ編集できる（`svg` / `backdrop` は画像、`group` は解除して子要素を個別に配置）

| kind | 内容 |
|---|---|
| `shape`（既定） | 図形。`geom` は `rect`（既定）/ `roundRect` / `ellipse` / `triangle` / `homePlate`（矢羽根）/ `chevron` / `flowChartDecision` / `flowChartMerge` / `flowChartDocument` / `can` / `flowChartMagneticDisk` / `borderCallout1` / `borderCallout2` / 線（`line` / `straightConnector1` / `bentConnector2`〜`5`）/ `custom`（`path` に `{"cmds": [["M",x,y],["L",x,y],["C",…],["Z"]], "fill": bool, "stroke": bool}` の配列）。`adj` は PowerPoint の調整値（`{"adj": 13400}` 等）。`rot`（度）/ `flipH` / `flipV` / `shadow`（`{dx, dy, blur, color}`）も可 |
| `table` | 表。`cols`（列幅 px）と `rows`（`{"h", "cells"}`）。セルは `paragraphs` / `fill` / `pad`（[左,上,右,下]）/ `anchor`（`t`/`ctr`/`b`）/ `borders`（`l`/`r`/`t`/`b` に線指定）/ `span` / `rowspan` / `merged`（結合で隠れるセル。`"h"` か `"v"`）/ `vert`（縦書き）/ `nowrap`（折り返さない）/ `clip`（はみ出しを隠す） |
| `svg` | ベクターアイコン（インライン SVG。要素・属性とも許可リスト方式で浄化され、`script` / `foreignObject` / イベント属性 / 外部参照（`#` 以外の href・`url()`）は除去される。DOCTYPE を含むものや解析できないものはエラー。id は衝突しないよう自動で接頭辞が付く）。PPTX では PNG 化して貼る |
| `backdrop` | 全面背景の写真の近似（`grid`: `{"cols", "rows", "colors": [...]}` の色格子をぼかして描く。画像は埋め込まない） |
| `placeholder` | 埋め込まない画像の代わりの枠（`label` を中央に表示） |
| `group` | 回転したグループ（`rot` / `origin`: [cx, cy] / `children`） |

- `fill` は色のほか `{"gradient": {"angle": 90, "stops": [[0, "#…"], [100, "#…"]]}}` / `{"pattern": "ltDnDiag", "fg": "#…", "bg": "#…"}`
- `line` は `{"color", "width", "dash"（dash/sysDash/sysDot/lgDash…）, "cap", "head"/"tail": {"type": "triangle|arrow|stealth|oval|diamond", "w", "len"}}`
- `text` は `{"insets": [左,上,右,下], "anchor", "anchorCtr", "wrap": false（折り返しなし）, "vert": true（縦書き）, "rot", "paragraphs": [...]}`。文字は図形ごとの文字領域（楕円なら内接矩形、ひし形なら中央の半分など PowerPoint と同じ）に置かれる
- 段落は `{"align": "l|ctr|r|just", "lineHeight": 1.0（行間100%の倍率）| "lineHeightPx", "spaceBefore", "spaceAfter", "marL", "indent", "bullet": {"char", "color", "size", "font"}, "runs": [...]}`。ランは `{"text", "size", "bold", "italic", "underline", "strike", "baseline", "color", "highlight", "font": ["Arial", "Meiryo UI"]}` か改行 `{"br": true}`

**取り込み手順**（既存 PPTX → canvas デッキ）:
```bash
python tools/pptx_import.py <src.pptx> --into <deck_dir> [--title "…"] [--slides 1 5]
# ↑ deck.json が既にあると書き込まずに終了する（丸ごと置き換えになるため）。承認後に --confirm を付けて再実行（元は deck.json.bak に退避）
python tools/build_deck.py <deck_dir> --html
python tools/preview_deck.py <deck_dir>
pwsh tools/export_pptx_png.ps1 -Src <src.pptx> -OutDir <deck_dir>/_work/ref   # Windows + PowerPoint で元資料を画像化
python tools/compare_ref.py <deck_dir> <deck_dir>/_work/ref                  # 上=元・下=HTML の比較画像と差分スコア
python tools/check_layout.py <deck_dir>                                       # 見切れ・スライド外へのはみ出し
```
- ラスタ画像（スクリーンショット等）は埋め込まず `placeholder` にする。SVG アイコンはベクターのまま、全面背景の写真は `backdrop` で近似、埋め込み Excel はブックの表示範囲（`oleSize`）を表にする（`openpyxl` が必要。範囲が 300行 × 60列・6000セルを超える場合は枠になる）
- `check_layout.py` は canvas では「見切れ（clip）」「スライド外へのはみ出し（bleed）」だけを判定する（重なり等は元資料の配置そのものなので判定しない）

## 検証（ビルド時にチェックされる内容）

`build_deck.py` はビルド前に deck.json 全体を検証する。**エラー（`error:`）はビルドを停止**し、**警告（`warning:`）はビルドを続けたまま報告**する。メッセージには可能な限り「N枚目（type=xxx）」が含まれるので、報告されたスライド番号から修正箇所を特定できる。

### エラー（ビルド停止）になる条件
- スライドに `type` が無い、または未知の `type`
- `color` / `fill` / `*_color` / `*_fill` / `marker_color` / `row_fills` の値、bullets 項目の `color` が「テーマ colors のキー」でも「`#RRGGBB` / `#RGB`」でもない（typo 検出。例: `primry` → 「テーマトークン名か #RRGGBB を指定してください」）
- `meta.layout_overrides` のトップキーが未知の `type`
- `table` の各行のセル数が `columns` 数と不一致、`col_widths` の長さが `columns` 数と不一致
- `image` / `image_text` の `path` が未指定、デッキフォルダの外を指す、存在しない、対応外の拡張子
- `swimlane` の `node.id` 重複、`edges` の `from`/`to` が未知 `id`、`lanes` が空、`legend_items` の各要素が4要素配列にも受理される辞書形式にも該当しない
- `architecture` / `dataflow` / `lifecycle` / `sequence`: ノード（`states`/`participants`）の `id` 重複・欠落、`edges`（`transitions`/`messages`）の `from`/`to` が未知 `id`、`row`/`col` が0以上の整数でない、同じ `(row, col)` の重複、`nodes`/`states` が空、`sequence` の `messages[].id` 重複
- `meta.id` に `\ / : * ? " < > |` や制御文字を含む

### 警告（ビルドは続行）になる条件
- `meta.layout_overrides[type]` や `slides[i].style` のトップキー（領域名）が、そのタイプの既定領域に無い（typo の可能性。候補が提示される。例:「'boddy' は bullets の領域名ではありません（候補: body）」）
- `matrix` の `quadrants` が4個以外
- `swimlane` のノードの `col` が `cols` 以上（自動拡張される）
- `architecture` / `dataflow` / `lifecycle` / `sequence` の**配線・ラベル・文字量などの幾何診断**（`too-dense` / `label-collision` / `edge-through-node` / `group-leak` / `out-of-grid` / `node-text-overflow` など）はビルドを止めず警告として報告される。詳しくは次項「図解タイプの診断」を参照
- タイトル・リード文・箇条書き本文・表などが**枠の高さを超える見込み**（文字あふれの推定）。「N枚目（type）: body が枠の高さを約 X px 超える見込み。項目を減らすか style.body.size を下げてください」のように表示される
- `meta.id` がフォルダ名と異なる（省略時はこの警告は出ない）

文字あふれの推定は、テーマのフォント（`fonts.body` / 見出しは `fonts.heading`）のフォントファイルを Pillow で実測した字幅で行う（英単語は途中で切らない・行頭禁則文字は前の行に残す、という描画側の挙動に寄せて折り返す）。Pillow かフォントファイルが見つからない環境では、全角 1.0 / 半角 0.55 の近似になる。

ビルドとは別に、`lint_deck_text.py`（文言・構成・日付の整合）と `check_visual.py`（プレビュー画像の下1/3の空白・似たスライドの連続）も警告を出す。

警告が出たら無視せず、内容に沿って `style` を調整するか項目数を減らして再ビルドする（`create-deck` スキルの手順4、または `review-deck` スキルでまとめて確認できる）。

### 図解タイプの診断（`check_diagram.py`）

`architecture` / `dataflow` / `lifecycle` / `sequence` / `swimlane` の配線・ラベル・密度は、専用 CLI で deck.json だけを読んでビルドせずに診断できる（Playwright / python-pptx 不要）:

```bash
python "$TOOLS/check_diagram.py" <deck_dir>                 # テキスト報告
python "$TOOLS/check_diagram.py" <deck_dir> --json out.json # JSON 出力（code / subject / evidence / fixes）
python "$TOOLS/check_diagram.py" <deck_dir> --strict        # warning も不合格にする
python "$TOOLS/check_diagram.py" <deck_dir> --slides 3 7    # 対象スライド番号（deck.json 内、1始まり）を絞る
```

**exit 1 になるのは診断に error が1件でもあるとき**（`--strict` を付けると warning も含める）。ここが `build_deck.py` と異なる点として、`edge-through-node` や `node-text-overflow` は診断としては error 相当でも、`build_deck.py` の通常ビルドは（見た目が崩れているだけで座標計算自体は破綻していないため）止めずに警告として報告する。**「`check_diagram.py` は error と言うのにビルドは通る」のはこの理由による意図した挙動**で、矢印の向きやラベルの意味の正しさまでは診断できないので、`check_diagram.py` を通したうえで `preview_deck.py` の目視確認も行う。

修理ループの進め方は `references/diagram-guide.md` の「修理ループ」を参照。

| code | level | 内容 | fixes の例 |
|---|---|---|---|
| `duplicate-id` | error | ノード/状態/メッセージの `id` が重複 | id を一意にする |
| `missing-id` | error | ノードに `id` が無い | 一意な id（英数字）を付ける |
| `empty` | error | `nodes`/`states`/`lanes` が空 | 1個以上書く |
| `cell-collision` | error | 同じ `(row, col)` に2ノード | どちらかの `row`/`col` を変える |
| `invalid-position` | error | `row`/`col` が0以上の整数でない、`lane` が `lanes` の範囲外 | 整数にする／`lanes` に行を追加する |
| `unknown-endpoint` | error（`edges`/`groups`/`messages` の参照）／warning（`activations`/`segments`） | `from`/`to`/`nodes` が存在しない `id` を指す | 存在する `id` を指定する |
| `invalid-group` | error | `groups[]` の要素がオブジェクトでない | オブジェクトにする |
| `edge-through-node` | error（`check_diagram.py`）／ビルドは warning 扱い | エッジが無関係なノードを横切る | `via` を指定する／`row`/`col` を変える／`from_side`/`to_side` を指定する |
| `node-text-overflow` | error または warning（あふれ量による。`check_diagram.py`）／ビルドは warning 扱い | `label`/`sublabel` が箱に収まらない | `label` を短くする／`cols`/`rows` を減らす／`node_size` を下げる |
| `label-collision` | warning | ラベルが他要素と重なる | `label_at` を指定する／`row`/`col` を離す／文言を短くする |
| `crossings` | warning（2箇所以上）／info（1箇所） | エッジ同士が交差する | `row`/`col` を入れ替える／戻りの線を `from_side`/`to_side` で外側に回す |
| `edge-overlap` | warning | 無関係なエッジが同じ線上で重なる | 片方に `via` を指定する／`row`/`col` をずらす |
| `too-dense` | warning | ノード>12／列>6／メッセージ>12／参加者>7 | 要素を減らす／2枚に分ける |
| `group-leak` | warning | `groups` の範囲内に非メンバーが混入 | メンバーの `row`/`col` を隣接させる／範囲外へ動かす |
| `out-of-grid` | warning | `cols`/`rows` を超える `row`/`col` があり自動拡張された | `cols`/`rows` を明示する |
| `short-segment` | info | 8px未満の短いセグメント | `row`/`col` の間隔を広げる／`via` で単純化する |
| `unknown-key` | warning | 未知のフィールド名（typo の可能性。候補が提示される） | `deck-schema.md` の該当タイプのキー名に直す |
| `unknown-type` | warning | ノードの `type` が未対応 | 近い `type` に直す（不明なら省略して `generic`） |
| `unknown-variant` | warning | `variant` が未対応 | `default`/`emphasis`/`security`/`dashed`/`muted` のいずれかにする |
| `unknown-kind` | warning | lifecycle の `kind` が未対応 | 近い `kind` に直す |
| `style-conflict` | warning | `edges` の `style` と `variant` が矛盾 | `variant` だけを書く |
| `side-ignored` | warning | 指定した `from_side`/`to_side` では他ノードを避けられず無視された | 指定を外す／別の辺にする |
| `invalid-side` | warning | `from_side`/`to_side` の値が不正 | `left`/`right`/`top`/`bottom` のいずれかにする |
| `invalid-via` | warning | `via` の形式が不正 | `[[x, y], ...]` の形にする |
| `missing-label` | warning | ノード/メッセージに `label` が無い | 表示名・やり取りの内容を `label` に書く |
| `empty-group` | warning | `groups[].nodes` が空 | ノード id を1個以上書く |

## 文字量・要素量の目安

| タイプ | 目安 |
|---|---|
| `title` の `title` | 25字以内 |
| `lead` | 60字以内 |
| `bullets` の項目数 | 3〜6項目、1項目40字以内 |
| `table` の行数 | 6行以内 |
| `cards` の枚数 | 3〜6枚（列数は3前後） |
| `steps` | 3〜5ステップ |
| `matrix` の `quadrants` | 必ず4個 |
| `architecture`/`dataflow`/`lifecycle` のノード数 | 12個以下 |
| 同上の列（`cols`） | 6以下 |
| `sequence` の参加者 | 7人以下 |
| `sequence` のメッセージ数 | 12本以下 |
| 図解タイプのエッジ `label` | 全角8〜12字程度 |

超える場合はスライドを分ける、`two_column`/`cards` などの別タイプに分割する、または `style` でフォントサイズ・行間を調整する。目安を超えても即エラーにはならないが、`check_layout.py` / ビルド時の文字あふれ警告で検出されやすくなる。

## ビルドとプレビュー

```bash
# <deck_dir> は deck.json があるフォルダ。$TOOLS はビルダーの場所:
#   プラグイン利用時: "${CLAUDE_PLUGIN_ROOT}/tools" / このリポジトリ内: plugins/slide-deck/tools
python "$TOOLS/build_deck.py" <deck_dir>            # HTML + PPTX
python "$TOOLS/build_deck.py" <deck_dir> --html      # HTML のみ（高速）
python "$TOOLS/preview_deck.py" <deck_dir> 5         # 5枚目だけPNG化して目視確認
python "$TOOLS/preview_deck.py" <deck_dir>           # 全スライドPNG化
python "$TOOLS/check_layout.py" <deck_dir>           # 構造チェック（はみ出し・重なり）
python "$TOOLS/lint_deck_text.py" <deck_dir>         # 文言チェック
python "$TOOLS/export_pdf.py" <deck_dir>             # PDF書き出し（要 LibreOffice）
```
`preview_deck.py` / `check_layout.py` / `contact_sheet.py` の総枚数は、`agenda` の自動繰り越しや `swimlane` の凡例自動挿入を含めた**実際のビルド後の枚数**を使う（deck.json に書いた `slides` の要素数そのものではない）。

### 微修正ループ（推奨ワークフロー）

1. `deck.json` の該当スライドの `style`（または内容）だけを編集
2. `build_deck.py <deck_dir> --html` → `preview_deck.py <deck_dir> <番号>` で当該スライドのみ確認
3. 納得したら `build_deck.py <deck_dir>` で PPTX も再生成

ビルドは全体でも1秒未満なので、再生成コストを気にする必要はない。**生成物（build/ 配下）は絶対に直接編集しない**。

## 注意

- PPTX にスピーカーノートは出力しない仕様（python-pptx の notes_slide が Keynote 互換性を壊すため）
- 色は必ずテーマトークン（`primary`, `accent` など）で指定し、hex 直書きはスライド固有の特例に限る（テーマ切替が効かなくなるため）。テーマトークンでも hex でもない値を指定するとビルドエラーになる
- 新しいテーマは `tools/new_theme.py <name>` で雛形を作り、`colors`/`fonts` を編集して `meta.theme` を切り替えるだけでよい。テーマは `default` をベースにマージされ、明示していないトークンは自動導出されるので上書きしたいトークンだけ書けばよい（詳細は `themes.md`）
